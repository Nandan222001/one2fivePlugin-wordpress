<?php
/**
 * The template for displaying No Reviews Found.
 *
 * @package one2five
 */

declare(strict_types = 1);

namespace One2Five;

?>

<div class="one2five-bootstrap">
	<div class="container">
		<div class="row">
			<h3 class="text-dark d-flex">No reviews found for this product</h3>
		</div>
	</div>
</div>