<?php

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
}
if ( isset( $_POST['submit_language'] ) && check_admin_referer( 'add_language_action', 'add_language_nonce' ) ) {
    $new_language = sanitize_text_field( $_POST['new_language'] );
    
    if ( ! empty( $_FILES['language_file']['name'] ) ) {
        $uploadedfile = $_FILES['language_file'];
    
        $file_ext = pathinfo($uploadedfile['name'], PATHINFO_EXTENSION);
    
        if ( strtolower($file_ext) !== 'json' ) {
            wp_die( __( 'Please upload a valid JSON file.' ) );
        }
        $upload = wp_handle_upload( $uploadedfile, array( 'test_form' => false ) );
        if ( isset( $upload['error'] ) ) {
            wp_die( $upload['error'] );
        }
    
        $json_file_url = $upload['url']; 
    } else {
        $json_file_url = '';
    }
    
    $languages = get_option( 'added_languages', [] );

    if ( ! empty( $new_language ) && ! array_key_exists( $new_language, $languages ) ) {
        $languages[ $new_language ] = $json_file_url; 
        update_option( 'added_languages', $languages );
    }

    wp_safe_redirect( admin_url( 'admin.php?page=manage-languages' ) );
    exit;
}
		// echo "<pre>";
		// print_r($translations);
if ( isset( $_POST['delete_language'] ) && check_admin_referer( 'delete_language_action_' . $_POST['language_to_delete'], 'delete_language_nonce' ) ) {
    $language_to_delete = sanitize_text_field( $_POST['language_to_delete'] );

    $languages = get_option( 'added_languages', [] );

    if ( array_key_exists( $language_to_delete, $languages ) ) {
        unset( $languages[ $language_to_delete ] );
        update_option( 'added_languages', $languages );
    }

    wp_safe_redirect( admin_url( 'admin.php?page=manage-languages' ) );
    exit;
}

$languages = get_option( 'added_languages', [] );
?>

<div class="wrap">
    <h1><?php echo esc_html($translations['manage_languages']['label']); ?></h1>
    <p><?php echo esc_html($translations['manage_languages']['description']); ?></p>

    <!-- Add New Language Form -->
    <form method="post" action="" enctype="multipart/form-data" onsubmit="return validateForm()">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">
                    <label for="new_language"><?php echo esc_html($translations['manage_languages']['add_language']['label']); ?></label>
                </th>
                <td>
                    <input type="text" id="new_language" name="new_language" value="" placeholder="<?php echo esc_html($translations['manage_languages']['add_language']['placeholder']); ?>" required />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="language_file"><?php echo esc_html($translations['manage_languages']['language_file']['label']); ?></label>
                </th>
                <td>
                    <input type="file" id="language_file" name="language_file" accept=".json" required />
                    <!-- Download Default JSON Template -->
                    <br>
                    <a href="<?php echo plugin_dir_url(__FILE__) . 'default_template.json'; ?>" class="button" download><?php echo esc_html($translations['manage_languages']['language_file']['description']); ?></a>
                </td>
            </tr>
        </table>
        
        <!-- Nonce for security -->
        <?php wp_nonce_field( 'add_language_action', 'add_language_nonce' ); ?>

        <!-- Submit button -->
        <p class="submit">
            <input type="submit" name="submit_language" class="button-primary" value="<?php echo esc_html($translations['manage_languages']['add_language']['label']); ?>" />
        </p>
    </form>

    <hr />

    <!-- Display the list of added languages -->
    <h2><?php echo esc_html($translations['manage_languages']['added_languages']['label']); ?></h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php echo esc_html($translations['manage_languages']['added_languages']['headers']['language']); ?></th>
                <th><?php echo esc_html($translations['manage_languages']['added_languages']['headers']['json_file']); ?></th>
                <th><?php echo esc_html($translations['manage_languages']['added_languages']['headers']['actions']); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ( ! empty( $languages ) ) : ?>
                <?php foreach ( $languages as $language => $file_url ) : ?>
                    <tr>
                        <td><?php echo esc_html( $language ); ?></td>
                        <td>
                            <?php if ( ! empty( $file_url ) ) : ?>
                                <a href="<?php echo esc_url( $file_url ); ?>" target="_blank"><?php echo esc_html($translations['manage_languages']['download_json']['label']); ?></a>
                            <?php else : ?>
                                <?php _e( 'No file uploaded', 'one2five' ); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo admin_url( 'admin.php?page=edit-language&language=' . urlencode( $language ) ); ?>" class="button"><?php echo esc_html($translations['manage_languages']['edit']['label']); ?></a>
                            <form method="post" action="" style="display:inline;">
                                <?php wp_nonce_field( 'delete_language_action_' . esc_attr( $language ), 'delete_language_nonce' ); ?>
                                <input type="hidden" name="language_to_delete" value="<?php echo esc_attr( $language ); ?>" />
                                <input type="submit" name="delete_language" value="<?php echo esc_html($translations['manage_languages']['delete']['label']); ?>" class="button-secondary" />
                            </form> 
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="3"><?php _e( 'No languages added yet.', 'one2five' ); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<script>
function validateForm() {
    var newLanguage = document.getElementById('new_language').value.trim();
    var languageFile = document.getElementById('language_file').value;

    if (newLanguage === '') {
        alert('<?php _e( 'Language name is required.', 'one2five' ); ?>');
        return false;
    }

    if (languageFile === '') {
        alert('<?php _e( 'Please upload a JSON file.', 'one2five' ); ?>');
        return false;
    }

    return true;
}
</script>

