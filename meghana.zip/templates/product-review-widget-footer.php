<?php
/**
 * The template for displaying the Footer of review widget.
 *
 * @package one2five
 */

declare(strict_types = 1);

namespace One2Five;

?>

</div>
</div>