jQuery(function($) {
    $('.color-field').wpColorPicker();
});